wp_favorites_plugin
===================

Wordpress plugin to save your favorite posts. Shortcodes are also available to enable favoriting posts.
