{{#compare total per_page operator=">"}}
<div class="paging">
  <span class="previous">
    {{{previous page}}}
  </span>
  {{{current page per_page total}}}
  <span class="next">
    {{{next has_more page}}}
  </span>
</div>
{{/compare}}